package com.pg.endproject.sensor.SensorMicroservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TrendsListModel {

	private String id;
	private String seriesPropertyId;
	private List<Series> series;
	
	public String getId() {
		return id;
	}
	
	@JsonProperty("Id")
	public void setId(String id) {
		this.id = id;
	}
	
	public String getSeriesPropertyId() {
		return seriesPropertyId;
	}
	
	@JsonProperty("SeriesPropertyId")
	public void setSeriesPropertyId(String seriesPropertyId) {
		this.seriesPropertyId = seriesPropertyId;
	}
	
	public List<Series> getSeries() {
		return series;
	}
	
	@JsonProperty("Series")
	public void setSeries(List<Series> series) {
		this.series = series;
	}
}


