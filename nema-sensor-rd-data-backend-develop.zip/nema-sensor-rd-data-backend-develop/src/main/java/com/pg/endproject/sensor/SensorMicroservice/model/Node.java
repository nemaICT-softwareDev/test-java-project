package com.pg.endproject.sensor.SensorMicroservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
//import com.pg.endproject.sensor.SensorMicroservice.model.Attributes;


public class Node {
	
		private String location;		
		private String name;
		private String descriptor;
		private String objectId;	
		private Attributes attributes;
		private String subTypeDescriptor;
		
		
		public String getSubTypeDescriptor() {
			return subTypeDescriptor;
		}
		
		public void setSubTypeDescriptor(String subTypeDescriptor) {
			this.subTypeDescriptor = subTypeDescriptor;
		}
		
		@JsonIgnore()
		public Attributes getAttributes() {
			return attributes;
		}
		
		@JsonProperty("Attributes")
		public void setAttributes(Attributes attributes) {
			this.attributes = attributes;
			this.subTypeDescriptor=attributes.getSubTypeDescriptor();
		}

		public String getLocation() {
			return location;
		}
		
		@JsonProperty("Location")
		public void setLocation(String location) {
			this.location = location;
		}
		public String getName() {
			return name;
		}
		
		@JsonProperty("Name")
		public void setName(String name) {
			this.name = name;
		}
		public String getDescriptor() {
			return descriptor;
		}
		
		@JsonProperty("Descriptor")
		public void setDescriptor(String descriptor) {
			this.descriptor = descriptor;
		}
		
		@JsonProperty("ObjectId")
		public String getObjectId() {
			return objectId;
		}
		
		public void setObjectId(String objectId) {
			this.objectId = objectId;
		}
		
}	