package com.pg.endproject.sensor.SensorMicroservice.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class RoomDataModel {
	
	private List<Node> nodes;

	public List<Node> getNodes() {
		return nodes;
	}
	
	@JsonProperty("Nodes")
	public void setNodes(List<Node> nodes) {
		this.nodes = nodes;
	}	
}


	
	

