package com.pg.endproject.sensor.SensorMicroservice;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;

import com.pg.endproject.sensor.SensorMicroservice.service.AccessTokenService;

@Configuration
public class SensorServiceConfig {

	@Autowired
	AccessTokenService tokenService;

	@Bean
	public RestTemplate getRestTemplate() {

		RestTemplate template = new RestTemplate();
		List<ClientHttpRequestInterceptor> list = template.getInterceptors();

		if (list == null) {
			list = new ArrayList<ClientHttpRequestInterceptor>();
		}

		list.add(new ClientHttpRequestInterceptor() {

			@Override
			public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
					throws IOException {
				 tokenService.regenerateAccessToken();
				return execution.execute(request, body);
			}
		});

		list.add(new ClientHttpRequestInterceptor() {

			@Override
			public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
					throws IOException {
				String token = tokenService.getAccesstoken();
				request.getHeaders().add("Authorization", "Bearer " + token);
				return execution.execute(request, body);
			}
		});

		template.setInterceptors(list);
		return template;

	}

}
