package com.pg.endproject.sensor.SensorMicroservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TrendSeriesAggregatorModel {

	private String id;
	private String seriesPropertyId;
	private List<SeriesAggregator> series;

	public String getId() {
		return id;
	}

	@JsonProperty("Id")
	public void setId(String id) {
		this.id = id;
	}

	public String getSeriesPropertyId() {
		return seriesPropertyId;
	}

	@JsonProperty("SeriesPropertyId")
	public void setSeriesPropertyId(String seriesPropertyId) {
		this.seriesPropertyId = seriesPropertyId;
	}

	@JsonProperty("Series")
	public void setSeries(List<SeriesAggregator> series) {
		this.series = series;
	}

	public List<SeriesAggregator> getSeries() {
		return series;
	}	
}


