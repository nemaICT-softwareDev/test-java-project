package com.pg.endproject.sensor.SensorMicroservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesInfoModel;

@Service
public class TrendSeriesInfoService {

	@Autowired
	RestTemplate restTemplate;

	@Value("${baseUrl}")
	private String baseUrl;
	
	private Logger logger = LoggerFactory.getLogger(TrendSeriesInfoService.class);
	
	public Map<String,List<String>> getTrendSeriesInfo() {

		
		List<TrendSeriesInfoModel> resp = null;
		List<String> trendseriesId = new ArrayList<String>();
		List<String> objectId= new ArrayList<String>();
		try {

			resp = getTrendSeriesInfoById("1");
			trendseriesId= resp.stream().map( x-> x.getTrendseriesId() ).collect(Collectors.toList());
			objectId= resp.stream().map( x-> x.getObjectId() ).collect(Collectors.toList());
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
		Map<String, List<String>> map = new HashMap();
		map.put("trendSeriesId", trendseriesId);
		map.put("objectId", objectId);
		return map;
	}

	
	public List<TrendSeriesInfoModel> getTrendSeriesInfoById(String objectId) {

		String url = baseUrl + "trendseriesinfo/";
		List<TrendSeriesInfoModel> resp = null;
		try {

			logger.debug(url);
			
			ResponseEntity<List<TrendSeriesInfoModel>> response = this.restTemplate.exchange(url + objectId, HttpMethod.GET,null,
					new  ParameterizedTypeReference<List<TrendSeriesInfoModel>>() {});
		 
		
			resp = response.getBody();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
		return resp;
	}

}
