package com.pg.endproject.sensor.SensorMicroservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pg.endproject.sensor.SensorMicroservice.model.RoomDataModel;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesAggregatorModel;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesBorderModel;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesInfoModel;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendsListModel;
import com.pg.endproject.sensor.SensorMicroservice.service.AccessTokenService;
import com.pg.endproject.sensor.SensorMicroservice.service.RoomDataService;
import com.pg.endproject.sensor.SensorMicroservice.service.TrendSeriesBorderService;
import com.pg.endproject.sensor.SensorMicroservice.service.TrendSeriesInfoService;
import com.pg.endproject.sensor.SensorMicroservice.service.TrendsAggregatorService;
import com.pg.endproject.sensor.SensorMicroservice.service.TrendsListService;

@RestController
@CrossOrigin
public class SensorController {

	@Autowired
	AccessTokenService accessTokenService;
	@Autowired
	TrendSeriesInfoService trendSeriesInfoService;
	@Autowired 
	TrendSeriesBorderService  trendSeriesBorder;
	@Autowired 
	TrendsListService trendsListService;
	@Autowired 
	TrendsAggregatorService trendsAggregator;
	@Autowired 
	RoomDataService roomDataService;
	
	@GetMapping("/test")
	public @ResponseBody String greeting() {
		return "Hello, World";
	}	

	@GetMapping("/token")
	public String getToken() {

		return accessTokenService.getAccesstoken();
	}

	@GetMapping(value = { "/trendSeriesInfo/{id}", })
	public List<TrendSeriesInfoModel> getTrendSeriesInfoForId(@PathVariable(required = false) String id) {
		
		if (id == null) {
			id = "1";
		}
		return trendSeriesInfoService.getTrendSeriesInfoById(id);
	}
	
	@GetMapping(value = {  "/trendSeriesInfo" })
	public Map<String,List<String>> getTrendSeriesInfo() {
		
		return trendSeriesInfoService.getTrendSeriesInfo();
	}
	
	@GetMapping(value = { "/trendSeriesBorder/{id}"})
	public TrendSeriesBorderModel getTrendSeriesBorder(@PathVariable() String id) {
		return trendSeriesBorder.getTrendSeriesBorder(id);
	}
	
	@GetMapping(value = { "/trendSeriesList/{id}"})
	public TrendsListModel getTrendSeriesList(@PathVariable() String id, @RequestParam(required = false) String to,
											  @RequestParam(required = false) String from) {
		System.out.println(from );
		System.out.println(to);
		return trendsListService.getTrendSeriesBorder(id,from,to);
	}
	
	@GetMapping(value = { "/trendSeriesAggregator/{id}/{interval}"})
	public TrendSeriesAggregatorModel getTrendSeriesAggregator(@PathVariable() String id, @PathVariable() int interval, @RequestParam(required = true) String to,
															   @RequestParam(required = true) String from) {
		return trendsAggregator.getTrendSeriesAggregator(id,from,to,interval);
	}
	
	@GetMapping(value = { "/rooms/{roomId}"})
	public RoomDataModel getRoomsData(@PathVariable("roomId") String roomId  ) {
		return roomDataService.getRoomData(roomId);
	}	
	
}
