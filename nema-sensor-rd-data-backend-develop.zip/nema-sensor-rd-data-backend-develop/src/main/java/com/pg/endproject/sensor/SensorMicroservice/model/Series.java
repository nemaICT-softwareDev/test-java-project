package com.pg.endproject.sensor.SensorMicroservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

 //@JsonIgnoreProperties(value = {"hibernateLazyInitializer","handler"})
public class Series{
	
	private String value;
	private String quality;
	private boolean qualityGood;
	private String timeStamp;
	
	public String getValue() {
		return value;
	}
	
	@JsonProperty("Value")
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getQuality() {
		return quality;
	}
	
	@JsonProperty("Quality")
	public void setQuality(String quality) {
		this.quality = quality;
	}
	
	public boolean isQualityGood() {
		return qualityGood;
	}
	
	@JsonProperty("QualityGood")
	public void setQualityGood(boolean qualityGood) {
		this.qualityGood = qualityGood;
	}
	
	public String getTimeStamp() {
		return timeStamp;
	}
	
	@JsonProperty("Timestamp")
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
}