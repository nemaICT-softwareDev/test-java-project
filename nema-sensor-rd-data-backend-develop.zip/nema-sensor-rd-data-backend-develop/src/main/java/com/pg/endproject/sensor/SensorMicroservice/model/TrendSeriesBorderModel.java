package com.pg.endproject.sensor.SensorMicroservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TrendSeriesBorderModel {
	
	private String from;
	private String to;
	
	public String getFrom() {
		return from;
	}
	@JsonProperty("From")
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	@JsonProperty("To")
	public void setTo(String to) {
		this.to = to;
	}
}
