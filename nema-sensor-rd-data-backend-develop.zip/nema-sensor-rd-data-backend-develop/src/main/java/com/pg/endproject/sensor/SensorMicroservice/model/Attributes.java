package com.pg.endproject.sensor.SensorMicroservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

class Attributes{
	
	private String subTypeDescriptor;

	public String getSubTypeDescriptor() {
		return subTypeDescriptor;
	}
	
	@JsonProperty("SubTypeDescriptor")
	public void setSubTypeDescriptor(String subTypeDescriptor) {
		this.subTypeDescriptor = subTypeDescriptor;
	}
}
