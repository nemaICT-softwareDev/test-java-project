package com.pg.endproject.sensor.SensorMicroservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TrendSeriesInfoModel {

	private String objectId;
	private int propertyIndex;
	private String propertyName;
	private String collectorObjectOrPropertyId;
	private String trendseriesId;
	private String trendType;
	
	public int getPropertyIndex() {
		return propertyIndex;
	}
	
	public String getObjectId() {
		return objectId;
	}
	
	@JsonProperty("ObjectId")
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	
	@JsonProperty("PropertyIndex")
	public void setPropertyIndex(int propertyIndex) {
		this.propertyIndex = propertyIndex;
	}
	
	public String getPropertyName() {
		return propertyName;
	}
	
	@JsonProperty("PropertyName")
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	
	public String getCollectorObjectOrPropertyId() {
		return collectorObjectOrPropertyId;
	}
	
	@JsonProperty("CollectorObjectOrPropertyId")
	public void setCollectorObjectOrPropertyId(String collectorObjectOrPropertyId) {
		this.collectorObjectOrPropertyId = collectorObjectOrPropertyId;
	}
	
	public String getTrendseriesId() {
		return trendseriesId;
	}
	
	@JsonProperty("TrendseriesId")
	public void setTrendseriesId(String trendseriesId) {
		this.trendseriesId = trendseriesId;
	}
	
	public String getTrendType() {
		return trendType;
	}
	
	@JsonProperty("TrendType")
	public void setTrendType(String trendType) {
		this.trendType = trendType;
	}	
	
}
