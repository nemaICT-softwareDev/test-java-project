package com.pg.endproject.sensor.SensorMicroservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.pg.endproject.sensor.SensorMicroservice.model.Node;
import com.pg.endproject.sensor.SensorMicroservice.model.RoomDataModel;

@Service
public class RoomDataService {

	@Autowired
	RestTemplate restTemplate;

	@Value("${baseUrl}")
	private String baseUrl;
	private Logger logger = LoggerFactory.getLogger(RoomDataService.class);

	private String[] j28RoomSet1 = new String[]{"J2801", "J2802","J2803","J2804"};
	private String[] j28RoomSet2 = new String[]{"J2805", "J2806","J2807","J2808"};
	

	public RoomDataModel getRoomData(String roomId) {

		RoomDataModel resp = new RoomDataModel();

		try {
			/*
			 * String url = baseUrl +
			 * "systembrowser/1?searchOption=0&caseSensitive=false&groupByParent=false&objecttypeFilter={\"6700\":[]}&searchstring=*"
			 * + roomId + "*";
			 */		

			String localRoomId = roomId;
			
			// angular will pass J28-1 or J28-2 in case of J28 rooms set to decide on rooms
			boolean filteringNeeded = false;

			if(localRoomId.contains("-")) {
				filteringNeeded = true;

				localRoomId = localRoomId.substring(0, 3); // take first 3 characters like J28 
			}


			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString( baseUrl + "systembrowser/1")
					.queryParam("searchstring", "*"+localRoomId+"*")
					.queryParam("searchOption", 0)
					.queryParam("caseSensitive", false)
					.queryParam("groupByParent", false)
					.queryParam("objecttypeFilter", "{\"6700\":[]}");

			//String url = builder.build().toUri()

			//String url = baseUrl + "systembrowser/1?searchstring=*J1203*&searchOption=0&caseSensitive=false&groupByParent=false&objecttypeFilter={\"6700\":[]}";
			logger.info(builder.build().toUriString());


			ResponseEntity<RoomDataModel> response = this.restTemplate.exchange(builder.build().toUri(), HttpMethod.GET, null,
					new ParameterizedTypeReference<RoomDataModel>() {
			});

			resp = response.getBody();

			if(filteringNeeded) {
				resp.setNodes(resp.getNodes().stream().filter(

						(node) ->{
							if(roomId.endsWith("-1")) {
								return node.getName().contains("J2801")
										|| node.getName().contains("J2802")
										||  node.getName().contains("J2803")
										|| node.getName().contains("J2804");	
							}
							else {
								
									return node.getName().contains("J2805")
											|| node.getName().contains("J2806")
											||  node.getName().contains("J2807")
											|| node.getName().contains("J2808");	
								}
							}
						).toList());
			}
		} catch (

				Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();

			logger.error(e.getMessage(), e);
		}
		return resp;

	}

}
