package com.pg.endproject.sensor.SensorMicroservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.json.BasicJsonParser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * 
 * @author lopesdasilva.n.1 This service handles the generation of access token
 *
 */
@Service
public class AccessTokenService {

	private String accesstoken = null;
	private RestTemplate restTemplate = new RestTemplate();

	@Autowired LoggingService logger;
	// TODO make it configurable
	@Value("${user}")
	private String username;
	
	@Value("${password}")
	private String password;
	
	
	@Value("${baseUrl}")
	private String baseUrl;
	
	@Value("${accessTokenExpiry}")
	private int accessTokenExpiry;
	
	//
	private long accessTokenRenewTime;
	
	
	private void generateAccessToken() {

		String url=baseUrl+ "token";
		try {
			
			logger.debug("URL is " + url);
			
			//logger.info("test info");
			//logger.error("test error", null);
			MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
			body.add("grant_type", "password");
			body.add("username", username);

			body.add("password", password);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

			HttpEntity entity = new HttpEntity<>(body, headers);

					
			ResponseEntity<String> response = this.restTemplate.postForEntity(url, entity, String.class);
			BasicJsonParser parser = new BasicJsonParser();
			String token = (String) parser.parseMap(response.getBody()).get("access_token");

		
			if (token != null && !token.isEmpty()) {
				accesstoken = token;
				accessTokenRenewTime = System.currentTimeMillis() + accessTokenExpiry;
			}
		} catch (RestClientException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			
			logger.error(e.getMessage(), e);
		}

	}

	// This is the method which will be called by Request interceptor to generate the
	// access token
	public String getAccesstoken() {
		if (accesstoken == null || accesstoken.isEmpty()) {
			generateAccessToken();
		}
		return accesstoken;
	}
	
	public void regenerateAccessToken() {
		long current = System.currentTimeMillis();
		if(current>=accessTokenRenewTime) {
			
			logger.info("Clearing access token as it is expired");
			accesstoken=null;
		}
	}

}
