package com.pg.endproject.sensor.SensorMicroservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesAggregatorModel;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendsListModel;

@Service
public class TrendsAggregatorService {

	@Autowired
	RestTemplate restTemplate;
	
	@Value("${baseUrl}")
	private String baseUrl;
	
	private Logger logger = LoggerFactory.getLogger(TrendsAggregatorService.class);
	
	public TrendSeriesAggregatorModel getTrendSeriesAggregator(String trendSeriesId, String from, String to , int interval) {


		String url = baseUrl + "trendseries/";

		TrendSeriesAggregatorModel resp = null;
		try {
				
			//logger.debug("baseUrl is " + url);
			if (trendSeriesId != null) {
				url = url + trendSeriesId + "/" + interval;
				if(from!=null && to!=null) {
					url = url + "?from="+ from + "&to="+ to;
				}
				
				logger.debug(url);

				ResponseEntity<TrendSeriesAggregatorModel> response = this.restTemplate.exchange(url, HttpMethod.GET, null,
						new ParameterizedTypeReference<TrendSeriesAggregatorModel>() {
						});

				resp = response.getBody();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			
			logger.error(e.getMessage(), e);
		}
		return resp;
	}

}
