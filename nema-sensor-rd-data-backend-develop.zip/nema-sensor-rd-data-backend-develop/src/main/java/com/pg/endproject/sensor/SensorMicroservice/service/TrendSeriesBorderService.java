package com.pg.endproject.sensor.SensorMicroservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesBorderModel;

@Service
public class TrendSeriesBorderService {

	@Autowired
	RestTemplate restTemplate;

	@Value("${baseUrl}")
	private String baseUrl;
	// DesigoCC1:GmsDevice_1_2105345_83886101.general.Data:_offline.._value/borders
	
	private Logger logger = LoggerFactory.getLogger(TrendSeriesBorderService.class);

	public TrendSeriesBorderModel getTrendSeriesBorder(String trendSeriesId) {

		String url = baseUrl + "trendseries/";
		TrendSeriesBorderModel resp = null;
		try {

			if (trendSeriesId != null) {
				url = url + trendSeriesId + "/borders";

				logger.debug(url);
				
				ResponseEntity<TrendSeriesBorderModel> response = this.restTemplate.exchange(url, HttpMethod.GET, null,
						new ParameterizedTypeReference<TrendSeriesBorderModel>() {
						});

				resp = response.getBody();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
		return resp;
	}

}
