package com.pg.endproject.sensor.SensorMicroservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SeriesAggregator {
	
	
	private double avgX;
	private double avgY;
	private int count;
	private String fromValueDescriptor;
	private double fromValue;
	private String fromTime;
	private double min;
	private double max;
	private double stDevX;
	private double stDevY;
	private double sumX;
	private double sumY;
	private double sumXX;
	private double sumXY;
	private double sumYY;
	private String toTime;
	private String toValueDescriptor;
	private double toValue;
	private double varX;
	private double varY;

	public double getAvgX() {
		return avgX;
	}

	@JsonProperty("AvgX")
	public void setAvgX(double avgX) {
		this.avgX = avgX;
	}

	public double getAvgY() {
		return avgY;
	}

	@JsonProperty("AvgY")
	public void setAvgY(double avgY) {
		this.avgY = avgY;
	}

	public int getCount() {
		return count;
	}

	@JsonProperty("Count")
	public void setCount(int count) {
		this.count = count;
	}

	public String getFromValueDescriptor() {
		return fromValueDescriptor;
	}

	@JsonProperty("FromValueDescriptor")
	public void setFromValueDescriptor(String fromValueDescriptor) {
		this.fromValueDescriptor = fromValueDescriptor;
	}

	public double getFromValue() {
		return fromValue;
	}

	@JsonProperty("FromValue")
	public void setFromValue(double fromValue) {
		this.fromValue = fromValue;
	}

	public String getFromTime() {
		return fromTime;
	}

	@JsonProperty("FromTime")
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}

	public double getMin() {
		return min;
	}

	@JsonProperty("Min")

	public void setMin(double min) {
		this.min = min;
	}

	public double getMax() {
		return max;
	}

	@JsonProperty("Max")

	public void setMax(double max) {
		this.max = max;
	}

	public double getStDevX() {
		return stDevX;
	}

	@JsonProperty("StDevX")

	public void setStDevX(double stDevX) {
		this.stDevX = stDevX;
	}

	public double getStDevY() {
		return stDevY;
	}

	@JsonProperty("StDevY")

	public void setStDevY(double stDevY) {
		this.stDevY = stDevY;
	}

	public double getSumX() {
		return sumX;
	}

	@JsonProperty("SumX")

	public void setSumX(double sumX) {
		this.sumX = sumX;
	}

	public double getSumY() {
		return sumY;
	}

	@JsonProperty("SumY")

	public void setSumY(double sumY) {
		this.sumY = sumY;
	}

	public double getSumXX() {
		return sumXX;
	}

	@JsonProperty("SumXX")

	public void setSumXX(double sumXX) {
		this.sumXX = sumXX;
	}

	public double getSumXY() {
		return sumXY;
	}

	@JsonProperty("SumXY")

	public void setSumXY(double sumXY) {
		this.sumXY = sumXY;
	}

	public double getSumYY() {
		return sumYY;
	}

	@JsonProperty("SumYY")

	public void setSumYY(double sumYY) {
		this.sumYY = sumYY;
	}

	public String getToTime() {
		return toTime;
	}

	@JsonProperty("ToTime")

	public void setToTime(String toTime) {
		this.toTime = toTime;
	}

	public String getToValueDescriptor() {
		return toValueDescriptor;
	}

	@JsonProperty("ToValueDescriptor")

	public void setToValueDescriptor(String toValueDescriptor) {
		this.toValueDescriptor = toValueDescriptor;
	}

	public double getToValue() {
		return toValue;
	}

	@JsonProperty("ToValue")

	public void setToValue(double toValue) {
		this.toValue = toValue;
	}

	public double getVarX() {
		return varX;
	}

	@JsonProperty("VarX")

	public void setVarX(double varX) {
		this.varX = varX;
	}

	public double getVarY() {
		return varY;
	}

	@JsonProperty("VarY")
	public void setVarY(double varY) {
		this.varY = varY;
	}

}


