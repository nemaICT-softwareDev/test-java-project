package com.pg.endproject.sensor.SensorMicroservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LoggingService {

	private Logger errorLogger = LoggerFactory.getLogger("ERROR");
	private Logger debugLogger = LoggerFactory.getLogger("DEBUG");
	private Logger infoLogger = LoggerFactory.getLogger("INFO");

	public void debug(String message) {
		debugLogger.debug(message);
	}

	public void info(String message) {
		infoLogger.info(message);

	}

	public void error(String message, Throwable t) {
		errorLogger.error(message, t);
	}

}
