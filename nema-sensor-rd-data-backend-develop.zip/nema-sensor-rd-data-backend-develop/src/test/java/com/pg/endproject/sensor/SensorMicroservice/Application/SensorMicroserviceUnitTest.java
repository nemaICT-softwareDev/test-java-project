package com.pg.endproject.sensor.SensorMicroservice.Application;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.pg.endproject.sensor.SensorMicroservice.controller.SensorController;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesInfoModel;
import com.pg.endproject.sensor.SensorMicroservice.service.TrendSeriesInfoService;

import util.TrendSeriesGenerator;

@ExtendWith(MockitoExtension.class)
public class SensorMicroserviceUnitTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@InjectMocks
	private SensorController controller;
	
	@Mock
	private TrendSeriesInfoService infoService;
	
	@BeforeEach
    public void init() {
		
        mockMvc = MockMvcBuilders.standaloneSetup(this, controller).build();        
        BDDMockito.lenient()
        .when(controller.getTrendSeriesInfoForId("DesigoCC1:GmsDevice_1_2105345_8"))
        .thenReturn(TrendSeriesGenerator.generateTrendSeriesInfoById());
   
        mockMvc = MockMvcBuilders.standaloneSetup(this, controller).build();        
        BDDMockito.lenient()
        .when(controller.getTrendSeriesInfo())
        .thenReturn(TrendSeriesGenerator.createTrendSeriesInfo());
	}
	
	
	@DisplayName("Ensures that TrendSeriesInfo(id) API Call Return Status Code 200")
	@Test
	void ensuresThatTrendSeriesInfoIdCallReturnStatusCode200() throws Exception {

		String objectID = "DesigoCC1:GmsDevice_1_2105345_8";
		List<TrendSeriesInfoModel> trendSeriesInfo = TrendSeriesGenerator.generateTrendSeriesInfoById();
		Mockito.when(controller.getTrendSeriesInfoForId(objectID)).thenReturn(trendSeriesInfo);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/trendSeriesInfo/"+objectID)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@DisplayName("Ensures that the content type starts with application/json")
	@Test 
	void ensureThatJsonIsReturnedAsContentType() throws Exception {
		
		String objectID = "DesigoCC1:GmsDevice_1_2105345_8";
		
		List<TrendSeriesInfoModel> trendSeriesInfo = TrendSeriesGenerator.generateTrendSeriesInfoById();
		Mockito.when(controller.getTrendSeriesInfoForId(objectID)).thenReturn(trendSeriesInfo);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/trendSeriesInfo/"+objectID)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().contentType("application/json;"));
	}
	
	@DisplayName("Ensures that json returned TrendSeriesInfo has same size as the generated TrendSeriesInfo")
	@Test
	void ensureListOfTrendSeriesInfo_whenGetTrendSeriesInfo_thenReturnTrendSeriesInfo() throws Exception{
		
		String objectID = "DesigoCC1:GmsDevice_1_2105345_8";
		List<TrendSeriesInfoModel> trendSeriesInfo = TrendSeriesGenerator.generateTrendSeriesInfoById();
		Mockito.when(controller.getTrendSeriesInfoForId(objectID)).thenReturn(trendSeriesInfo);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/trendSeriesInfo/"+objectID)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@DisplayName("Ensures that TrendSeriesInfo API Call Return Status Code 200")
	@Test
	void ensuresThatTrendSeriesInfoCallReturnStatus_whenCall_thenReturnsCode200() throws Exception {

		Map<String,List<String>> trendSeriesInfo = TrendSeriesGenerator.createTrendSeriesInfo();
		Mockito.when(controller.getTrendSeriesInfo()).thenReturn(trendSeriesInfo);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/trendSeriesInfo/")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@DisplayName("Ensures that the content type starts with application/json by TrendSeriesInfo")
	@Test 
	void ensureThatJsonIsReturnedAsContentTypeByTrendSeriesInfo_whenTrendSeriesInfo_thenReturnTrendSeriesInfo() throws Exception {		
		
		
		Map<String,List<String>> trendSeriesInfo = TrendSeriesGenerator.createTrendSeriesInfo();
		Mockito.when(controller.getTrendSeriesInfo()).thenReturn(trendSeriesInfo);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/trendSeriesInfo/")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().contentType("application/json;"));
	}
	
	@DisplayName("Ensures that json returned TrendSeriesInfo has same size as the generated TrendSeriesInfo")
	@Test
	void ensureListOfTrendSeriesInfoHasSameSize_whenGetTrendSeriesInfo_thenReturnTrendSeriesInfo() throws Exception{
		
		
		Map<String,List<String>> trendSeriesInfo = TrendSeriesGenerator.createTrendSeriesInfo();
		Mockito.when(controller.getTrendSeriesInfo()).thenReturn(trendSeriesInfo);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/trendSeriesInfo/")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
}
