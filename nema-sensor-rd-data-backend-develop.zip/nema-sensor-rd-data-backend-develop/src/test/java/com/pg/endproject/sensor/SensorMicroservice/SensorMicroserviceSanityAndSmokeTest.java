package com.pg.endproject.sensor.SensorMicroservice;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.pg.endproject.sensor.SensorMicroservice.controller.SensorController;

@SpringBootTest
class SensorMicroserviceSanityAndSmokeTest {

	/*
	 * This is a simple sanity and smoke test to check if the application context fail to start 
	 * and to check if the context is creating the controller
	 */
	@Autowired
	private SensorController sensorController;
	
	
	@Test
	void contextLoads() {
		
		assertThat(sensorController).isNotNull();
	}

}
