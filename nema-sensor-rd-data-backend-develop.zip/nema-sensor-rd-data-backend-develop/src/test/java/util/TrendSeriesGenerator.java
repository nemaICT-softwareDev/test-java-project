package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesBorderModel;
import com.pg.endproject.sensor.SensorMicroservice.model.TrendSeriesInfoModel;

public class TrendSeriesGenerator {
	
	
	
	public static List<TrendSeriesInfoModel> generateTrendSeriesInfoById(){
	

	List<TrendSeriesInfoModel> trendSeriesId = new ArrayList<TrendSeriesInfoModel>();

	
	TrendSeriesInfoModel model = new TrendSeriesInfoModel();

	model.setObjectId("DesigoCC1:GmsDevice_1_2105345_8");
    model.setPropertyIndex(1);
    model.setPropertyName("Present_Value");
    model.setCollectorObjectOrPropertyId("DesigoCC1:GmsDevice_1_2105345_83886101");
    model.setTrendseriesId("DesigoCC1:GmsDevice_1_2105345_83886101.general.Data:_offline.._value");
    model.setTrendType("TL");
	
    trendSeriesId.add(model);	
	return trendSeriesId;
	
	}
	
	public static Map<String,List<String>> createTrendSeriesInfo(){
		

		List<String> trendseriesId = new ArrayList<String>();
		List<String> objectId= new ArrayList<String>();

		
		TrendSeriesInfoModel model = new TrendSeriesInfoModel();

		model.setObjectId("DesigoCC1:GmsDevice_1_2105345_8");
	    model.setPropertyIndex(1);
	    model.setPropertyName("Present_Value");
	    model.setCollectorObjectOrPropertyId("DesigoCC1:GmsDevice_1_2105345_83886101");
	    model.setTrendseriesId("DesigoCC1:GmsDevice_1_2105345_83886101.general.Data:_offline.._value");
	    model.setTrendType("TL");
	    
	    String id = model.getTrendseriesId();
	    trendseriesId.add(id);
	    String objID = model.getObjectId();
	    objectId.add(objID);
	    Map<String, List<String>> map = new HashMap();
		map.put("trendSeriesId", trendseriesId);
		map.put("objectId", objectId);
		return map;	
	
		}
	
	public static TrendSeriesBorderModel generateTrendSeriesBorder() {
		
		
		String from = "2023-01-04T10:00:37.25Z";
		String to = "2023-02-20T16:43:10.48Z";
		
		TrendSeriesBorderModel model = new TrendSeriesBorderModel();
		model.setFrom(from);
		model.setTo(to);
		
		return model;
	}
}
